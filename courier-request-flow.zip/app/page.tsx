"use client"

import CourierRequestFlow from "../courier-request-flow"

export default function SyntheticV0PageForDeployment() {
  return <CourierRequestFlow />
}